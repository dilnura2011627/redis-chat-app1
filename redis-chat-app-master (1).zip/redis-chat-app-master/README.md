# Redis asosida Real-Time Chat Ilovasi

Ushbu loyiha 4-modul topshirig‘i uchun bajarildi.

Loyiha Next.js 14, TypeScript, Tailwind CSS va Upstash Redis
texnologiyalari asosida ishlab chiqilgan.

Loyiha ochiq manbali GitHub repository’dan fork qilingan
va o‘rganish hamda moslashtirish maqsadida ishlatildi.

## Asosiy imkoniyatlar
- Autentifikatsiya (Login / Register)
- Real-time chat
- Rasm yuborish
- Light / Dark mode
- Responsive dizayn

## Asl loyiha muallifi
https://github.com/burakorkmez
